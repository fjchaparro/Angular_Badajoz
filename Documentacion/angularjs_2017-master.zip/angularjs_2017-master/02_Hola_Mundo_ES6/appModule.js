
angular.module('appMain', [])





