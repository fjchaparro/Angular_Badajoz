angular.module('appMenuComponentes')
.value("textos", {
    'titulo' : 'Inicios de Angular 1.6 @2017',
    'autor' : 'Alejandro L. Cerezo',
    'correo' : 'alcerezo@movistar.es',
    'lugar' : 'Madrid',
    'empresa' : 'DesFufor' 
})
