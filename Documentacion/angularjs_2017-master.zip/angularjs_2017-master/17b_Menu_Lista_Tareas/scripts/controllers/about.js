'use strict';

/**
 * @ngdoc function
 * @name appModule.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the appModule
 */
angular.module('appModule')
  .controller('AboutCtrl', ['$scope', function ($scope) {

  }]);
