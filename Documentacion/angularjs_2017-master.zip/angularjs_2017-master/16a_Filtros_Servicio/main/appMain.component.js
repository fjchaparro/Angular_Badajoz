class AppMainController {
} // Fin de la clase MainController

angular.module('appPrueba')
.component("appMain", {
	templateUrl: "main/app.main.template.html",
	controller: AppMainController
})



