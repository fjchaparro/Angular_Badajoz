// Tercera aproximación al formato "1.5"
// Se define el controller como una clase

class MainController {

    constructor () {
    }

    $onInit () {   

   }

} // Fin de la clase MainController

angular.module('appPrueba',[])
.controller('MainController', MainController)

