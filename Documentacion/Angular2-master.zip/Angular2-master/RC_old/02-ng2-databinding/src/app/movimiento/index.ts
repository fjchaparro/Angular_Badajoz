export { MovimientoComponent } from './movimiento.component';
