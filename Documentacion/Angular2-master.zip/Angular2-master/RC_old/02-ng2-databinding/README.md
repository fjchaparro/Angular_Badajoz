# 2 Data Binding

[Artículo de acompañamiento](http://academia-binaria.com/databinding-el-flujo-de-datos-de-angular2/)