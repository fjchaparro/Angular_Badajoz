#Hola mundo en Angular 2

[Artículo de acompañamiento](http://academia-binaria.com/hola-mundo-en-angular-2/)
