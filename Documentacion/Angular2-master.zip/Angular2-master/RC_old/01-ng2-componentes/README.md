# Componentes en Angular 2

[Artículo de acompañamiento](http://academia-binaria.com/componentes-los-bloques-de-construccion-de-angular-2/)