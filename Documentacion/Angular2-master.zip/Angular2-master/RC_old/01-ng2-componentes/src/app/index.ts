/** este fichero actua como indice del barril app
 * exporta todo lo que hay en los ficheros que representa
*/

/** el objeto que configura el entorno de ejecución */
export * from './environment';
/** la clase que gestiona el componente root de la aplicación */
export * from './cash-flow.component';
