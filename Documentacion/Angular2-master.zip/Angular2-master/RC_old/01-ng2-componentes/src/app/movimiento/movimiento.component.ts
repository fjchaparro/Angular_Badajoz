import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-movimiento',
  templateUrl: 'movimiento.component.html',
  styleUrls: ['movimiento.component.css']
})
export class MovimientoComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
