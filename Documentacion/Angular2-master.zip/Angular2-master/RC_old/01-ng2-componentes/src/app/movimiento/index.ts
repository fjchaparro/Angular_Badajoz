/** indice, exportador del barril movimiento
 * se habrá apuntado en system.config*/

/** realmente exporta un solo componente llamado MovimientoComponent */
export * from './movimiento.component';
