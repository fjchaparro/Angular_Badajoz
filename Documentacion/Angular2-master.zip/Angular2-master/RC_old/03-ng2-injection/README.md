#3 Inyección de dependencias

[Artículo de acompañamiento](http://academia-binaria.com/angular2-di-inyeccion-de-dependencias/)