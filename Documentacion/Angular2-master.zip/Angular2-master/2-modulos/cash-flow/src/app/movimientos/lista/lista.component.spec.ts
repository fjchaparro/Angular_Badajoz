/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ListaComponent } from './lista.component';

describe('Component: Lista', () => {
  it('should create an instance', () => {
    let component = new ListaComponent();
    expect(component).toBeTruthy();
  });
});
