/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { MovimientosComponent } from './movimientos.component';

describe('Component: Movimientos', () => {
  it('should create an instance', () => {
    let component = new MovimientosComponent();
    expect(component).toBeTruthy();
  });
});
