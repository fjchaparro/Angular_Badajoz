/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { NuevoComponent } from './nuevo.component';

describe('Component: Nuevo', () => {
  it('should create an instance', () => {
    let component = new NuevoComponent();
    expect(component).toBeTruthy();
  });
});
