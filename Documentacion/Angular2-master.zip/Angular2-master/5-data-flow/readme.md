[Data Flow](http://academia-binaria.com/angular2-di-inyeccion-de-dependencias/)

Comunicación entre componentes usando atributos

### Guía
- `nuevo.component.ts` :  Eliminar la dependencia del servicio y sustituirla por comunicación con su contenedor
- `lista.component.ts` :  Eliminar la dependencia del servicio y sustituirla por comunicación con su contenedor
- `movimientos.component.ts` :  Usa los servicios para manipular datos y se comunica con los componentes simples
- `movimientos.component.html` :  La plantilla se comunica con los componentes hijos mediante [propiedades] y (eventos)
()
