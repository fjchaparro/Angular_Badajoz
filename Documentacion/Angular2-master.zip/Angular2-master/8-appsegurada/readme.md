[appsegurada]()

Servidor de datos y consumo desde el cliente

### Guía
- `/cash-flow` : ciclo de seguridad local
- `/seguridad` : formulario y servicio
- `to do` : editor/borrador de un movimiento 
()
