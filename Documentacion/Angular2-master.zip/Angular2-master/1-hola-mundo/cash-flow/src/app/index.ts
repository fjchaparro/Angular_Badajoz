/** fichero índice que facilita la importación de otros ficheros
 *  si cualquier fichero indexado cambiase de ruta
 *  sólo tendríamos que tocar en este índice
 */
export * from './app.component';
export * from './app.module';
