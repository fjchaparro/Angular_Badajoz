[appsegurada]()

Servidor de datos y consumo desde el cliente

### Guía
- `package.json` : Material Design 
- `app.module.ts` : imports MaterialModule 
- `app.component.html` : md-sidenav-layout md-sidenav md-toolbar #sidenav 
- `seguridad.component.html` : md-input md-button 
- `nuevo.component.html` : md-radio-group md-radio-button md-card
- `lista.component.html` : md-list md-list-item md-line md-icon 
- `ng build -prod` :  
- `/dist -> /cliente` : 
- `future` : forms, sockets, universal, pwa, lazy

### Renderizado isomórfico en el servidor
https://github.com/angular/universal-starter
https://universal.angular.io/quickstart/

### Forms
https://toddmotto.com/angular-2-forms-reactive


### Sockets
https://github.com/jussikinnula/angular2-socketio-chat-example
http://www.syntaxsuccess.com/viewarticle/socket.io-with-rxjs-in-angular-2.0

### PWA
https://mobile.angular.io/

