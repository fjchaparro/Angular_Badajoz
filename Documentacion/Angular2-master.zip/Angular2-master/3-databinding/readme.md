[Data Binding](http://academia-binaria.com/databinding-el-flujo-de-datos-de-angular2/)

Enlace entre plantillas y modelos

### Guía
- `nuevo.component.html` : directivas para enlace de datos. atributos, propiedades y eventos
- `nuevo.component.ts` : modelo en clase controladora

(https://scotch.io/tutorials/how-to-deal-with-different-form-controls-in-angular-2)
