[Data Flow](http://academia-binaria.com/angular2-di-inyeccion-de-dependencias/)

Comunicación entre componentes usando atributos

### Guía
- `ng g m contacto` :  
- `contacto.component.html` :  
- `contacto.module.ts` :
- `app.module.ts` :
- `app.component.html` :
- `ng g c home` : 
- `ng g c saludo` :  
- `saludo.component.ts` :  
- `saludo.component.html` :  
()
