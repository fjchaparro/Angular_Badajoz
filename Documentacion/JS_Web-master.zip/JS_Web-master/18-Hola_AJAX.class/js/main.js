
//const oFormulario = new Formulario("Luis", "Desarrollo Web full-stack");
//oFormulario.controller()

new Formulario().controller()