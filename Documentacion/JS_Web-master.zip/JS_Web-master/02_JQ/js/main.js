
// En JS sería window.onload = 
// En JQ sería $(document).ready() 
// En JQ hay un atajo del anterior
$(function () {
    let sName = "Luis";
    let sCurso = "Desarrollo Web full-stack";
    new Formulario("Luis", "Desarrollo Web full-stack").controller()
})






